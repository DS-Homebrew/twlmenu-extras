A port of a theme I had on my 3DS (originaly made by Kazoomaster on "Theme Plaza" https://themeplaza.art/item/32746)
For \_nds\TWiLightMenu\dsimenu\themes