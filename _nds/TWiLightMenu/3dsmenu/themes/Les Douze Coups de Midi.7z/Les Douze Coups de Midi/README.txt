=================
Les Douze Coups de Midi (from the french TV show)
=================

Version: 1.0.0

Description:
Fan des Douze coups de Midi ? Cette emissio présentée par Jeeeaaaann Luuuuuuc !!! Découvrez ce thème à l'effigie de votre émission télévisée préférée.
QUI DIS ROUGE DIIIIIIIIIS DUEEELLLLLL

Credits:
- Dhalian: theme realization
- Jean-Michel Bernard: composer of the music of the "Douze cousp de Midi"
- TF1: designer of the "Douze Coups de Midi" logo
