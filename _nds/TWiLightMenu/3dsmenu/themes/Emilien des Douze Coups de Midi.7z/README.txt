=================
Emilien des Douze Coups de Midi (from the french TV show)
=================

Version: 1.0.0

Description:
Un thème de notre cher EMILIEN DES DOUZE COUPS 

Credits:
- Dhalian: theme creation
- Joe Dassin: singer of the "Les Yeux d'Emilie" song
- TF1: designer of the "Douze Coups de Midi" logo
