ReadMe:


Credits:
This skin was made by Jasper Smit.
More of my skins at:
http://tomssite.netau.net/wordpress/?page_id=23



How to Install:

1. 	Copy the "Vyanjan" folder to the ui folder in your system folder.
	so that is:		*sd card*/__ak2/ui/
	or with AKAIO: 	*sd card*/__aio/ui/

2. 	Start up your ds and acekard
3.	Go to "System Options" in the start menu
4. 	Change Interace Theme to "Vyanjan"
5.	press ok, press yes
6. 	done!

