Copy and paste this folder into root:\_nds\TWiLightMenu\akmenu\themes .
Delete the README.

root is the base of your SD card, where you haven't entered any files or folders.