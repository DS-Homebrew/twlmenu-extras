AK2DX Empress Theme for acekard2/2i/RPG by Piri_Silber
Tested on AK2 running AKAIO 1.5

Skin Based on Konami's IIDX EMPRESS, this second release adds the calendar, new buttons, menu, loading bar & window.
Now I can say that it's finally complete, even if I'm thinking about a little "Black Another" mod/recolor/whatever of that theme (because it'll maybe look great on my black DSi)


Massive thanks to :
Dan Taylor for his excellent Skin Editor
HES for the pretty visual designs he does since IIDX6 and which has inspired me.
GIMP, free & powerful should be the motto of that software.
easyelements.com, 'cause I was looking for brushes, and their site popped out of google when I typed "spark brush".
