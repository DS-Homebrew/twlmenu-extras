### AK2DX_Empress

Author: Piri_Silber

Date released: Unknown

Made for: AceKard

Custom font: No

### Other Credits

Dan Taylor for his excellent Skin Editor
HES for the pretty visual designs he does since IIDX6 and which has inspired me.
GIMP, free & powerful should be the motto of that software.
easyelements.com, 'cause I was looking for brushes, and their site popped out of google when I typed "spark brush".
