**Skin title:** PICO-8
**Author:** Vulpes-Vulpeos
**Released:** 20.03.2019
**Made for:** TWiLightMenu++
**Custom font:** Yes
**Screenshots:**
![preview](https://github.com/DS-Homebrew/twlmenu-extras/raw/master/_nds/TWiLightMenu/akmenu/themes/PICO-8/Preview.jpg)
**Additional features:**
There is black custom loading screen in `loading` folder. Replace files in `loading` folder with files from `loading/Black` folder. Don't forget to backup white loading screen files.
**Additional credits:** PICO-8 belongs to Lexaloffle Games. More info here: https://www.lexaloffle.com/pico-8.php