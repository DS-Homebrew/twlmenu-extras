### 3D Shadow the Hedgehog

Author: hairzo

Date released: April 13th 2010

Made for: AceKard

Custom font: No
