**Skin title:** Taswell
**Author:** Vulpes-Vulpeos
**Released:** 24.05.2019
**Made for:** TWiLightMenu++
**Custom font:** No
**Screenshots:**
![preview](https://github.com/DS-Homebrew/twlmenu-extras/raw/master/_nds/TWiLightMenu/akmenu/themes/Taswell/Preview.jpg)
**Additional features:**
No