# (theme name) iKard

**Author:**        axlace
**Release Date:**  2008

## Additional Features

- **Custom Font:** no
- **TWiLightMenu++ Enhanced:** no
