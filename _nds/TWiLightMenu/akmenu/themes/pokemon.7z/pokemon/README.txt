Thank you for trying out my theme. :)

~Jayro