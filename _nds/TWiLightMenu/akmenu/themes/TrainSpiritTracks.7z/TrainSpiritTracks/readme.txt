-------------------------------------
	   Skin By Hairzo
-------------------------------------
Legend of Zelda - Cole theme skin for the Acekard RPG by Chris Hair (hairzo)


Enjoy.

Put with in the __AIO/ui or __rpg/ui  folder and then select skin via the system settings menu on the RPGs OS


-------------------------------------
	      Contact
-------------------------------------
MSN:  hairzo2002@hotmail.com
