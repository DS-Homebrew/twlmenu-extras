### Dry Bones 3D

Author: hairzo

Made for: AceKard

Description: Dry Bones theme for Acekard RPG
