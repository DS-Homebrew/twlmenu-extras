-------------------------------------
	   Skin By Hairzo
-------------------------------------
Dry Bones theme skin for the Acekard RPG by Chris Hair (hairzo)


Enjoy.

Put with in the __rpg/ui/  folder and then select skin via the system settings menu on the RPGs OS


-------------------------------------
	      Contact
-------------------------------------
MSN:  hairzo2002@hotmail.com



-------------------------------------
	    Distribution
-------------------------------------
You may freely distribute this skin but must keep this .txt file with it.

Thanks.




